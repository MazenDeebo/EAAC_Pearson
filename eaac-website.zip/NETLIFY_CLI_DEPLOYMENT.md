# Netlify CLI Deployment Guide

## 🚀 Quick CLI Deployment Steps

### Method 1: Direct Deploy (Simplest)

```bash
# 1. Install Netlify CLI (if not already installed)
npm install -g netlify-cli

# 2. Login to Netlify (opens browser)
npx netlify-cli login

# 3. Deploy directly (creates new site)
npx netlify-cli deploy --prod --dir=.
```

### Method 2: Connect to GitHub Repository

```bash
# 1. Initialize Netlify site
npx netlify-cli init

# Choose: "Create & configure a new project"
# Site name: eaac-pearson-btec
# Build command: (leave empty)
# Directory to deploy: . (current directory)

# 2. Deploy
npx netlify-cli deploy --prod
```

## 📋 CLI Commands Reference

### Essential Commands:
```bash
# Check login status
npx netlify-cli status

# Deploy to preview (draft)
npx netlify-cli deploy

# Deploy to production
npx netlify-cli deploy --prod

# Open site in browser
npx netlify-cli open

# View site info
npx netlify-cli sites:list
```

### Troubleshooting Commands:
```bash
# Switch accounts
npx netlify-cli switch

# Logout and login again
npx netlify-cli logout
npx netlify-cli login

# Link to existing site
npx netlify-cli link
```

## 🎯 Expected Workflow

### When you run `npx netlify-cli deploy --prod --dir=.`:

1. **CLI will ask**: "This folder isn't linked to a site yet"
2. **Choose**: "Create & configure a new site"
3. **Team**: Select your team (usually your username)
4. **Site name**: Enter `eaac-pearson-btec` (or leave empty for random)
5. **Deploy**: CLI uploads all files and deploys

### Result:
- **Website URL**: `https://eaac-pearson-btec.netlify.app`
- **Admin URL**: `https://app.netlify.com/sites/eaac-pearson-btec`
- **Deploy time**: ~30 seconds

## 🔧 Alternative: Drag & Drop Method

If CLI has issues, you can also:

1. **Go to**: https://netlify.com
2. **Login** with GitHub
3. **Drag & Drop**: Zip your project folder to Netlify dashboard
4. **Deploy**: Instant deployment

### Create Zip File:
```bash
# Create deployment zip
powershell Compress-Archive -Path * -DestinationPath eaac-website.zip
```

## 📱 Post-Deployment Steps

### 1. Custom Domain (Optional)
```bash
# Add custom domain
npx netlify-cli sites:update --name eaac-pearson-btec
```

### 2. Environment Variables (If needed)
```bash
# Set environment variables
npx netlify-cli env:set SITE_NAME "EAAC Pearson BTEC"
```

### 3. Form Handling
- Forms automatically work on Netlify
- Check form submissions in Netlify dashboard
- Set up email notifications in site settings

## 🎉 Success Indicators

✅ **CLI Output**: "Deploy is live!"
✅ **Website URL**: Working and accessible
✅ **All Pages**: Loading correctly
✅ **Contact Forms**: Functional
✅ **Mobile**: Responsive design working

## 🆘 If CLI Fails

### Quick Web Deploy:
1. Go to https://app.netlify.com/drop
2. Drag your project folder
3. Instant deployment!

### Manual GitHub Connect:
1. Go to https://netlify.com
2. "New site from Git"
3. Choose GitHub → Your repository
4. Deploy settings: Build command (empty), Publish directory: `.`
5. Deploy!

---

**Your EAAC website will be live in under 2 minutes!** 🚀
